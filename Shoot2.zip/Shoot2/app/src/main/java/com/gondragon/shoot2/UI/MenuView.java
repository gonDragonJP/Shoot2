package com.gondragon.shoot2.UI;

import android.content.Context;
import android.view.View;


public class MenuView extends View {


    public MenuView(Context context) {

        super(context);


    }
}
