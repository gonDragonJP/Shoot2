package com.gondragon.shoot2.myplane;

import com.gondragon.shoot2.vector.Int2Vector;

public interface CallbackOfMyPlane {

    Int2Vector getMyPlanePos();
    void setMyPlanePos(Int2Vector planePos);
}
